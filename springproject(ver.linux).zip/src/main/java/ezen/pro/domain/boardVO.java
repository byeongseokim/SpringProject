package ezen.pro.domain;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class boardVO {

	private int bno;
	private String bcon;
	private String btie;
	private String bwriter;
	private String cate;
	private Date bdate;
	private int rownum;
	
	
}
