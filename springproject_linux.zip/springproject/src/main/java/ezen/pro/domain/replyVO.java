package ezen.pro.domain;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class replyVO {
	
	private String rwriter;
	private String rcon;
	private int rno;
	private int bno;
	private Date rdate;
	
}
