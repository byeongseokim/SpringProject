package ezen.pro.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class userVO {

	private String id;
	private String password;
	private String name;
	private String phone;
	private int grade;
	
}
