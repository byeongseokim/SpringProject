package ezen.pro.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class cateVO {
	
	private String cate;
}
